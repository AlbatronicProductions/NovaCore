using NovaCore.Core;
using NovaCore.Core.Surface;
using NovaCore.Graphics;
using NovaCore.Simulation.Celestial;
using NovaCore.Simulation.Spacecraft;
using NovaCore.Simulation.Spacecraft.Assemblies;
using NovaCore.Simulation.Time;

internal static class AssemblyFloridaSiteTests
{
    private static void Check(bool value,string message)
    {if(!value)throw new InvalidOperationException("FLORIDA SITE: "+message);}
    internal static void Cheap()
    {
        var root=GraphicsTestHarness.RepositoryPath();
        Check(EarthElevationDataset.TryLoad(Path.Combine(root,"assets","earth","runtime"),out var error),error);
        Check(TerrainAssetCache.TryResolveRequired(root,TerrainAssetCache.ProductionEarthLocalAssetId,null,out _,out var path,out error),error);
        Check(EarthLocalTerrainElevationDataset.TryLoad(path,out error),error);
        Check(PlanetaryPhysicalSurfacePointQuery.TryAcquire(6,root,out var query)==PhysicalSurfaceQueryStatus.Ready,"real terrain acquisition");
        // Midway between the existing platform edge and the full-weight grading edge.
        // The entire 16m patch is outside the authored 64m platform footprint.
        var east=(FloridaLaunchSite.PlatformEastWidthMetres*.5+FloridaFacilitySupport.Region.InnerEastMetres)*.5;
        var site=AssemblyFloridaSite.Create(query!,SimulationInstant.Zero,new(3),east);
        Check(east-8>FloridaLaunchSite.PlatformEastWidthMetres*.5,"ground patch clear of existing facility");
        var motion=new AssemblyMotion(new(.2,1.3,-.7),new(.05,-.03,.02),AssemblyContactProfile.Upright,new(.00002,.00001,-.00003));
        var maxPosition=0d;var maxVelocity=0d;
        foreach(var ticks in new[]{0L,16666,33333,10_000_000,20_000_000})
        {
            var time=new SimulationInstant(ticks);var earth=site.ToEarth(motion,time);var back=site.FromEarth(earth,time);
            maxPosition=Math.Max(maxPosition,Math.Sqrt((back.PositionO-motion.PositionO).LengthSquared));
            maxVelocity=Math.Max(maxVelocity,Math.Sqrt((back.VelocityO-motion.VelocityO).LengthSquared));
            Check(Math.Sqrt((back.AngularVelocityBody-motion.AngularVelocityBody).LengthSquared)<1e-15,"angular frame round trip");
            Check(CelestialBodyOrientationEvaluator.TryEvaluate(SolarSystemBodyIds.Earth,time,out var orientation),"banked Earth pose");
            var expected=orientation.BodyFixedToInertial.Rotate(site.OriginBodyFixed);
            Check(Math.Sqrt((expected-site.At(time).Position).LengthSquared)<1e-7,"current orientation owner agreement");
        }
        Check(maxPosition<1e-8&&maxVelocity<1e-10,"full physical frame round trip");
        var f=site.At(new(10_000_000));var before=site.At(new(9_999_000));var after=site.At(new(10_001_000));
        var derivative=(after.Position-before.Position)/.002;
        Check(Math.Sqrt((derivative-f.Velocity).LengthSquared)<2e-5,"independent centered position derivative");
        var testP=new Double3(.2,1,-.5);var testV=new Double3(.1,.05,.02);
        var local=site.LinearAcceleration(f,testP,testV);
        var r=f.Position+f.Orientation.Rotate(testP);var radius=Math.Sqrt(r.LengthSquared);
        var omega=f.Orientation.Rotate(f.Omega);var alpha=f.Orientation.Rotate(f.Alpha);
        var originA=Double3.Cross(alpha,f.Position)+Double3.Cross(omega,Double3.Cross(omega,f.Position));
        var reconstructed=originA+f.Orientation.Rotate(local+Double3.Cross(f.Omega,testV)*2+
            Double3.Cross(f.Omega,Double3.Cross(f.Omega,testP))+Double3.Cross(f.Alpha,testP));
        Check(Math.Sqrt((reconstructed-r*(-site.Mu/(radius*radius*radius))).LengthSquared)<2e-13,"inertial acceleration balance including tangential terms");
        Console.WriteLine($"FLORIDA_SITE_FRAME PASS positionRoundTrip={maxPosition:R} velocityRoundTrip={maxVelocity:R} derivativeError={Math.Sqrt((derivative-f.Velocity).LengthSquared):R} gravity={local} authority={site.Authority} east={east}");

        var d=AssemblyDevelopmentPropulsion.LoadDefault().Apply(AssemblyStockCatalog.LoadDefault().Resolve("novacore.stock.SRV01.FourHorn"));
        var launch=AssemblyLaunch.CreateFloridaSupported(d,new SpacecraftDefinition(new(305),new(1),new(2),"Development SRV-01 Florida ground"),"florida-ground",site);
        using var session=AssemblyApplicationSession.CreateSupported(launch);
        var world=session.Engine.AssemblyContactWorldForTest(session.Authority)!;var identity=world.AssemblyIdentityForTest;
        var maxPenetration=0d;var finalSupported=0;
        var tolerance=launch.ContactProfile!.SmallestFeature/1000;
        var settledOrigin=Double3.Zero;var settledHeight=0d;var drift=0d;var speed=0d;var angular=0d;
        for(var n=1;n<=1200;n++)
        {
            var ticks=(long)n*1_000_000/60-(long)(n-1)*1_000_000/60;
            Check(session.Engine.AdmitAssemblyHostTime(session.Authority,n,new(ticks)).Status==AssemblyFlightStatus.AcceptedCredit,"host credit");
            var result=session.Engine.ServiceAssemblyContactDebt(session.Authority);
            session.Engine.ObserveAssemblyFlight(session.Authority,out var observation);
            var minimum=double.MaxValue;
            var pose=observation.State.Motion;var q=pose.BodyToWorld;
            var ry0=2*(q.X*q.Y+q.Z*q.W);var ry1=1-2*(q.X*q.X+q.Z*q.Z);var ry2=2*(q.Y*q.Z-q.X*q.W);
            foreach(var child in launch.ContactProfile!.Children)for(var i=0;i<8;i++)
            {
                // Independent matrix arithmetic, not the production contact/pose helper.
                var x=((i&1)==0?-.5:.5)*child.Dimensions.X;var y=((i&2)==0?-.5:.5)*child.Dimensions.Y;var z=((i&4)==0?-.5:.5)*child.Dimensions.Z;
                var m=child.AtOrigin.Rotation;var o=child.AtOrigin.Position;
                var ax=o.X+m.A*x+m.B*y+m.C*z;var ay=o.Y+m.D*x+m.E*y+m.F*z;var az=o.Z+m.G*x+m.H*y+m.I*z;
                minimum=Math.Min(minimum,pose.PositionO.Y+ry0*ax+ry1*ay+ry2*az+1.7);
            }
            maxPenetration=Math.Max(maxPenetration,-minimum);
            if(n==600)settledOrigin=pose.PositionO;
            if(n>600)
            {
                settledHeight=Math.Max(settledHeight,Math.Abs(minimum));
                if(Math.Abs(minimum)<=2*tolerance)finalSupported++;
                var delta=pose.PositionO-settledOrigin;
                drift=Math.Max(drift,Math.Sqrt(delta.X*delta.X+delta.Z*delta.Z));
                speed=Math.Max(speed,Math.Sqrt(pose.VelocityO.LengthSquared));
                angular=Math.Max(angular,Math.Sqrt(pose.AngularVelocityBody.LengthSquared));
                Console.WriteLine($"FLORIDA_SITE_SETTLED n={n} height={Math.Abs(minimum):R} drift={drift:R} speed={speed:R} angular={angular:R}");
                Check(settledHeight<=2*tolerance,"settled height <= twice feature-derived tolerance");
                Check(drift<=tolerance,"settled drift <= feature-derived tolerance");
                Check(speed<=tolerance/.016667&&angular*launch.ContactProfile.BoundingRadius<=tolerance/.016667,"settled linear/angular surface speed");
            }
            if(n<=4||result.PublishedCount!=1||n==1200)
                Console.WriteLine($"FLORIDA_SITE_STEP n={n} status={result.Status} published={result.PublishedCount} tick={observation.State.Epoch.Ticks} penetration={-minimum:R} velocity={observation.State.Motion.VelocityO} omega={observation.State.Motion.AngularVelocityBody} private={world.AssemblyIdentityForTest}");
            Check(result.PublishedCount==1&&result.Status is AssemblyFlightStatus.AwaitingDebt or AssemblyFlightStatus.Completed,"first material contact result");
            Check(observation.State.Stores==launch.Initial.Stores&&observation.State.Mass==launch.Initial.Mass,"no resource/mass mutation");
            Check(maxPenetration<=.020,"20mm physical penetration ceiling");
            Check(observation.StateRevision.Value==(ulong)n&&observation.HistoryCount==n&&observation.Clock.Debt.Ticks==0&&observation.TimelineRevision.Value==0,"canonical accounting");
            Check(world.AssemblyIdentityForTest.Generation==identity.Generation&&world.AssemblyIdentityForTest.Body==identity.Body,"retained world/body");
        }
        Check(finalSupported==600,"final600 support");
        Console.WriteLine($"FLORIDA_SITE_CHEAP PASS peakPenetration={maxPenetration:R} support={finalSupported}/600 intervals=1200");
    }
}
