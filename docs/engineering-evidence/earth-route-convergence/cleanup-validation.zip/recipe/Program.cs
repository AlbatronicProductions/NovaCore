using NovaCore.Launcher;
using System.Diagnostics;
using System.Text.Json;

const string root = "E:/NovaCore";
var output = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"../../../../"));
NovaCoreLaunchPlan? florida = null;
var records = new List<object>();
foreach (var preset in new[] { NovaCoreScenarioPreset.SolarSystemOverview, NovaCoreScenarioPreset.EarthFarOrbital, NovaCoreScenarioPreset.Earth700Km, NovaCoreScenarioPreset.EarthFullscreenNative, NovaCoreScenarioPreset.FloridaLaunchSite, NovaCoreScenarioPreset.NewEarthRenderer })
{
    var definition = ScenarioCatalog.Get(preset);
    if (!ScenarioCatalog.TryCreateConfiguration(preset,definition.DefaultAltitudeMetres,definition.DefaultWindowMode,definition.DefaultResolution,definition.DefaultDiagnostics,3440,1440,out var config,out var error)) throw new Exception(error);
    var plan = NovaCoreProcessLauncher.CreatePlan(root,config!,"Release");
    if (!Path.GetFullPath(plan.FileName).Equals(Path.GetFullPath(Path.Combine(root,"samples/NovaCore.Triangle/bin/Release/net10.0/NovaCore.Triangle.exe")),StringComparison.OrdinalIgnoreCase)) throw new Exception("Launcher did not resolve current Release runtime");
    if (!File.Exists(plan.FileName)) throw new Exception("Missing deployed runtime");
    if (preset == NovaCoreScenarioPreset.FloridaLaunchSite)
    {
        florida = plan;
        string[] expected = ["--scene=sol","--focus=earth","--surface-site=florida-launch","--physical-surface=m12d-natural-candidate"];
        if (!plan.Arguments.SequenceEqual(expected)) throw new Exception("Florida scenario differs from accepted launcher configuration");
    }
    records.Add(new { preset=definition.DisplayName,plan.FileName,plan.Arguments,plan.WorkingDirectory,plan.EnvironmentVariables });
}
File.WriteAllText(Path.Combine(output,"launcher-route-probe.json"),JsonSerializer.Serialize(records,new JsonSerializerOptions { WriteIndented=true }));
Console.WriteLine("Launcher route probe PASS: six supported presets, current Release executable; exact Florida arguments");
if (!args.Contains("--smoke")) return 0;
var start = new ProcessStartInfo(florida!.FileName) { WorkingDirectory=florida.WorkingDirectory, UseShellExecute=false, RedirectStandardOutput=true, RedirectStandardError=true, CreateNoWindow=true, WindowStyle=ProcessWindowStyle.Hidden };
foreach (var key in start.Environment.Keys.Where(k=>k.StartsWith("NOVACORE_")&&(k.Contains("CAPTURE")||k.Contains("PROBE"))).ToArray()) start.Environment.Remove(key);
foreach (var item in florida.EnvironmentVariables) start.Environment[item.Key]=item.Value;
start.Environment["NOVACORE_EARTH_ROUTE_VALIDATION"]="florida";
start.Environment["VK_INSTANCE_LAYERS"]="VK_LAYER_KHRONOS_validation";
foreach (var argument in florida.Arguments) start.ArgumentList.Add(argument);
foreach (var argument in new[] { "--benchmark-frames=500","--log=vulkan","--log=validation" }) start.ArgumentList.Add(argument);
using var process=Process.Start(start) ?? throw new Exception("Runtime did not start");
var stdout=process.StandardOutput.ReadToEndAsync();var stderr=process.StandardError.ReadToEndAsync();
using var deadline=new CancellationTokenSource(TimeSpan.FromSeconds(110));
try { await process.WaitForExitAsync(deadline.Token); }
catch(OperationCanceledException) { process.Kill(entireProcessTree:true);await process.WaitForExitAsync();throw new Exception("Bounded Florida smoke timed out"); }
var log=await stdout;var err=await stderr;
File.WriteAllText(Path.Combine(output,"florida-smoke.log"),log);File.WriteAllText(Path.Combine(output,"florida-smoke.err"),err);
if(process.ExitCode!=0)throw new Exception("Runtime exit "+process.ExitCode);
if(!log.Contains("Earth route scenario validation: PASS"))throw new Exception("Scenario acceptance driver did not complete");
if(!log.Contains("NCSM1 regional ready:")||!log.Contains("Production spherical billboard publication:"))throw new Exception("NCSM1 did not publish ready physical terrain");
if(!log.Contains("Florida seating stability: frame=440")||!log.Contains("bodyFixedStable=true"))throw new Exception("Florida seating check did not complete");
if(log.Contains("zeroOwner=1")||log.Contains("overlapOwner=1")||log.Contains("staleGenerationDraws=1")||(log+err).Contains("device lost",StringComparison.OrdinalIgnoreCase))throw new Exception("Ownership/device failure");
var vuids=(log+err).Split('\n').Where(line=>line.Contains("VUID-")).ToArray();
if(vuids.Any(line=>!line.Contains("VUID-VkMemoryAllocateInfo-memoryTypeIndex-00645")))throw new Exception("New Vulkan validation message");
File.WriteAllText(Path.Combine(output,"smoke-result.json"),JsonSerializer.Serialize(new { pass=true,frames=500,exitCode=process.ExitCode,physicalProbeEnabled=false,bulkCaptureEnabled=false,knownKmtVuidLines=vuids.Length,manualAcceptance=false },new JsonSerializerOptions { WriteIndented=true }));
Console.WriteLine("Florida bounded smoke PASS: 500 frames, ready publication, stable seating, no new Vulkan/ownership/device regression; no bulk capture");
return 0;
