from pathlib import Path
import os,stat,ctypes,json,subprocess,collections,csv,time,hashlib
from ctypes import wintypes
R=Path('E:/NovaCore'); O=Path(__file__).parent
def git(*args):
 p=subprocess.run(['git','--no-optional-locks',*args],cwd=R,capture_output=True)
 if p.returncode not in (0,1):raise RuntimeError(p.stderr.decode())
 return p.stdout
initial=git('status','--short'); (O/'initial-status.txt').write_bytes(initial)
(O/'initial-diff.sha256').write_text(hashlib.sha256(git('diff','--binary')).hexdigest())
untracked=[x for x in git('ls-files','--others','--exclude-standard','-z').decode().split('\0') if x]
(O/'initial-untracked-hashes.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in untracked}))
tracked=set(p.casefold() for p in git('ls-files','-z').decode().split('\0') if p)
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE];k.CreateFileW.restype=wintypes.HANDLE
k.GetFileInformationByHandleEx.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD];k.GetFileInformationByHandleEx.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE]
class SI(ctypes.Structure):
 _fields_=[('allocation',ctypes.c_longlong),('eof',ctypes.c_longlong),('links',wintypes.DWORD),('pending',ctypes.c_ubyte),('directory',ctypes.c_ubyte)]
class FI(ctypes.Structure):
 _fields_=[('volume',ctypes.c_ulonglong),('fileid',ctypes.c_ubyte*16)]
def allocation(p):
 h=k.CreateFileW(str(p),0,7,None,3,0,None)
 if h==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
 try:
  si=SI()
  if not k.GetFileInformationByHandleEx(h,1,ctypes.byref(si),ctypes.sizeof(si)):raise ctypes.WinError(ctypes.get_last_error())
  fi=FI()
  if not k.GetFileInformationByHandleEx(h,18,ctypes.byref(fi),ctypes.sizeof(fi)):raise ctypes.WinError(ctypes.get_last_error())
  return si.allocation,f'{fi.volume}:{bytes(fi.fileid).hex()}',si.links
 finally:k.CloseHandle(h)
files=[];links=[];dirs=[];errors=[]
def walk(p):
 for e in os.scandir(p):
  try:
   s=e.stat(follow_symlinks=False); rel=Path(e.path).relative_to(R).as_posix()
   if s.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
    links.append(dict(path=rel,target=os.readlink(e.path),tag=hex(s.st_reparse_tag),isDirectory=bool(s.st_file_attributes&stat.FILE_ATTRIBUTE_DIRECTORY)));continue
   if e.is_dir(follow_symlinks=False):dirs.append(rel);walk(e.path)
   elif e.is_file(follow_symlinks=False):
    alloc,fid,nlinks=allocation(e.path)
    files.append(dict(path=rel,bytes=s.st_size,allocated=alloc,id=fid,hardLinks=nlinks,mtime=s.st_mtime_ns,extension=Path(e.name).suffix.lower(),git='outside Git' if rel.startswith('.git/') else 'tracked' if rel.casefold() in tracked else 'pending'))
  except OSError as ex:errors.append(dict(path=e.path,error=str(ex)))
start=time.time();walk(R)
pending=[f['path'] for f in files if f['git']=='pending']
p=subprocess.run(['git','--no-optional-locks','check-ignore','-z','--stdin'],cwd=R,input=('\0'.join(pending)+'\0').encode(),capture_output=True)
assert p.returncode in (0,1),p.stderr
ignored=set(p.stdout.decode().split('\0'))
for f in files:
 if f['git']=='pending':f['git']='ignored' if f['path'] in ignored else 'untracked'
groups={}
def summary(fs,dircount=0):
 unique={f['id']:f for f in fs}
 return dict(files=len(fs),directories=dircount,logical=sum(f['bytes'] for f in fs),allocated=sum(f['allocated'] for f in fs),uniqueAllocated=sum(f['allocated'] for f in unique.values()),git=dict(collections.Counter(f['git'] for f in fs)))
for name in sorted(set(f['path'].split('/')[0] for f in files)|set(x.split('/')[0] for x in dirs)):
 groups[name]=summary([f for f in files if f['path'].split('/')[0]==name],sum(x==name or x.startswith(name+'/') for x in dirs))
allids=collections.defaultdict(list)
for f in files:allids[f['id']].append(f['path'])
result=dict(root=str(R),scanSeconds=time.time()-start,totals=summary(files,len(dirs)),groups=groups,links=links,errors=errors,hardlinkGroups=[v for v in allids.values() if len(v)>1],multiplyLinkedFiles=[f for f in files if f['hardLinks']>1],directories=dirs,files=files)
(O/'physical-inventory.json').write_text(json.dumps(result,indent=2))
with (O/'physical-files.csv').open('w',newline='',encoding='utf-8-sig') as out:
 w=csv.DictWriter(out,fieldnames=list(files[0]));w.writeheader();w.writerows(files)
print('TOTAL',json.dumps(result['totals']),'errors',errors,'seconds',result['scanSeconds'])
for n,g in sorted(groups.items(),key=lambda x:x[1]['allocated'],reverse=True):print(n,json.dumps(g))
print('LINKS',json.dumps(links,indent=2));print('HARDLINK GROUPS',len(result['hardlinkGroups']),'multiplylinked',len(result['multiplyLinkedFiles']))
assert initial==git('status','--short')
