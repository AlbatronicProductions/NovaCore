from pathlib import Path
import subprocess,json,collections,re,hashlib,struct
R=Path('E:/NovaCore'); O=Path(__file__).parent
def git(*a,inp=None):
 p=subprocess.run(['git','--no-optional-locks',*a],cwd=R,input=inp,capture_output=True)
 if p.returncode: raise RuntimeError(p.stderr.decode(errors='replace'))
 return p.stdout
inv=json.loads((O/'physical-inventory.json').read_text())
tracked=git('ls-files','-z').decode().split('\0')[:-1]
(O/'protected-hashes.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in tracked}))
formats=[]
for f in inv['files']:
 if f['path'].endswith(('.ncpe','.nccube')):
  with (R/f['path']).open('rb') as s: h=s.read(128)
  formats.append(dict(path=f['path'],bytes=f['bytes'],magic=h[:8].hex(),version=struct.unpack_from('<I',h,8)[0] if h.startswith(b'NCCUBE') else struct.unpack_from('<H',h,4)[0],terrainVersion=struct.unpack_from('<I',h,48)[0] if h.startswith(b'NCCUBE2') else None))
(O/'artifact-inventory.json').write_text(json.dumps(formats,indent=2))
objects={}
for line in git('cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype) %(objectsize) %(objectsize:disk)').decode().splitlines():
 sha,kind,size,disk=line.split();objects[sha]=dict(kind=kind,size=int(size),disk=int(disk))
def reach(*args):return {l.split()[0] for l in git('rev-list','--objects',*args).decode().splitlines()}
refs=reach('--all'); reflogs=reach('--all','--reflog')
def sizes(ids):
 return dict(objects=len(ids),logical=sum(objects[x]['size'] for x in ids if x in objects),disk=sum(objects[x]['disk'] for x in ids if x in objects))
unreachable=set(objects)-refs
small=[s for s,o in objects.items() if o['kind']=='blob' and o['size']<1024]
raw=git('cat-file','--batch',inp=('\n'.join(small)+'\n').encode()); pos=0;lfs={}
for sha in small:
 end=raw.index(b'\n',pos); hdr=raw[pos:end].split(); n=int(hdr[-1]); blob=raw[end+1:end+1+n];pos=end+n+2
 if blob.startswith(b'version https://git-lfs.github.com/spec/v1\n'):
  m=re.search(rb'oid sha256:([a-f0-9]{64})\nsize (\d+)',blob)
  if m:
   oid=m[1].decode(); e=lfs.setdefault(oid,dict(size=int(m[2]),referencedByRefs=False,referencedByReflogs=False,pointerBlobs=[]));e['referencedByRefs']|=sha in refs;e['referencedByReflogs']|=sha in reflogs;e['pointerBlobs'].append(sha)
local=[]
for f in inv['files']:
 if f['path'].startswith('.git/lfs/objects/'):
  oid=Path(f['path']).name;local.append(dict(path=f['path'],bytes=f['bytes'],allocated=f['allocated'],**lfs.get(oid,dict(referencedByRefs=False,referencedByReflogs=False))))
packs=[]
for p in (R/'.git/objects/pack').glob('*.idx'):
 rows=git('verify-pack','-v',str(p)).decode().splitlines(); ids={x.split()[0] for x in rows if re.match(r'^[a-f0-9]{40} ',x)}
 packs.append(dict(path=p.with_suffix('.pack').relative_to(R).as_posix(),bytes=p.with_suffix('.pack').stat().st_size,objects=len(ids),reachable=len(ids&refs),reflogReachable=len(ids&reflogs)))
summary=dict(all=sizes(set(objects)),reachableRefs=sizes(set(objects)&refs),unreachableRefs=sizes(unreachable),unreachableIncludingReflogs=sizes(set(objects)-reflogs),packs=packs,lfsLocal=local,lfsPointerObjects=lfs,gitAllocated=inv['groups']['.git']['allocated'],temporaryGitObjects=[f for f in inv['files'] if f['path'].startswith('.git/objects/') and '/tmp_' in f['path']])
(O/'git-storage.json').write_text(json.dumps(summary,indent=2))
texts={p:(R/p).read_text(encoding='utf-8-sig',errors='replace') for p in tracked if p.endswith(('.cs','.cpp','.h','.inl','.glsl','.comp','.vert','.frag','.tesc','.tese','.csproj','.md','.sln')) and '/engineering-evidence/' not in p}
symbols=[]
for p,t in texts.items():
 if not p.startswith(('src/','tools/','samples/')) or not p.endswith('.cs'):continue
 for name in re.findall(r'\b(?:class|struct|enum|interface)\s+(\w+)',t):
  uses=[q for q,v in texts.items() if q!=p and re.search(r'\b'+re.escape(name)+r'\b',v)]
  if len(uses)<=1:symbols.append(dict(symbol=name,definition=p,otherFiles=uses))
(O/'low-consumer-symbols.json').write_text(json.dumps(symbols,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ('lfsLocal','lfsPointerObjects','temporaryGitObjects')},indent=2))
print('Local LFS bytes',sum(x['bytes'] for x in local),'referenced',sum(x['bytes'] for x in local if x['referencedByRefs']))
print('artifact inventory',json.dumps(formats,indent=2))
print('low consumer symbols',json.dumps(symbols,indent=2))
